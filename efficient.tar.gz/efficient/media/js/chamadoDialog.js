 $(function(){
        $( "#dialog-form" ).load("main.php?class=chamado&method=add").dialog({
            autoOpen: false,
            height: 550,
            width: 900,
            modal: true,
            buttons: {
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            },
            close: function() {
               $( this ).dialog( "close" );
            }
        });
 
        $( "#openChamado" )
            .click(function() {
                $( "#dialog-form" ).dialog( "open" );
            });
    });
	
	