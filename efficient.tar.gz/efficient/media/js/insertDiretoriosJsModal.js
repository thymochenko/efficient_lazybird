 $(function(){
		setInterval(function() {
				$('#image_').load('?class=paginas&method=indexUpdate&id=82 #image_');
				}, 5000);
				
        $("#dialog-form-diretorios")
		.load("main.php?class=diretorios&method=adicionar").dialog({
            autoOpen: false,
            height: 500,
            width: 800,
            modal: true,
            buttons: {
                Cancel: function() {
                    $(this).dialog("close");
                }
            },
            close: function() {
               $(this).dialog("close");
            }
        });
 
        $("#diretoriosAdd")
            .button()
            .click(function(){
				 windowReferer = window.open('mainAjax.php?class=diretorios&method=adicionar',
				'page',
				'toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=800,height=700'); 
                //$( "#dialog-form-diretorios" ).dialog("open");
            });
			
		$("#diretoriosUpd")
            .click(function(){
			     id = $("#inputUpd").val();
				 windowReferer = window.open('mainAjax.php?class=diretorios&method=atualizar&id=' + id,
				'page',
				'toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=800,height=700'); 
                //$( "#dialog-form-diretorios" ).dialog("open");
            });
    });