 $(function(){
		
        $( "#dialog-form-user" ).load("main.php?class=usuarios&method=add").dialog({
            autoOpen: false,
            height: 550,
            width: 900,
            modal: true,
            buttons: {
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            },
            close: function() {
               $( this ).dialog( "close" );
            }
        });
 
        $( "#openUsuario" )
            .click(function() {
                $( "#dialog-form-user" ).dialog( "open" );
            });
    });
	
	