	function popup(url){
		newwindow=window.open(url,'name','height=330,width=600');
		if (window.focus) {newwindow.focus()}
		return false;
	}