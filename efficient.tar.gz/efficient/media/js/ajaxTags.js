/**
$(): utilizado em todas as fun��es que devem ser referenciadas a jQuery
document: express�o que indica o documento HTML
ready(): associado a leitura do documento enquanto est� sendo carregado
*/
$(document).ready(function(){

    // Crio uma vari�vel chamada $forms que pega o valor da tag form
    $forms = $('.actionFormSendTags');

    // hide(): esconde a div cadastro enquanto carrega o ready()
    $('#ajax').hide();

    /**
     bind(): � manipulador de evento exemplo submit, click e/ou double click
     a: � a tag <a href>
    */

      $('#ajax').show(); // show(): mostra div que est� oculta (hide()).

    $forms.bind('submit', function(){

        /**
        Crio a vari�vel $button
        attr(): set a propriedade de um atributo, nesse exemplo foi desativado o bot�o com a tag button
        */
        var $button = $('button',this).attr('disabled',true);

        /**
       Criada a vari�vel params
        serialize(): pega os dados inseridos no formul�rio
        */
        var params = $(this.elements).serialize();
        //window.alert(params);DEBUG 
        var self = this;
        $.ajax({

            // Usando metodo Post
            type: 'POST',

            // this.action pega o script para onde vai ser enviado os dados
            url: this.action,

            // os dados que pegamos com a fun��o serialize()
            data: params, 
            
            // Antes de enviar
            beforeSend: function(){
                // mostro a div loading
                $('#loadingTags').show();

                //  html(): equivalente ao innerHTML
                $('#loadingTags').html("<h2>Carregando...</h2>");
				
            },
            success: function(txt){
                // Ativo o bot�o usando a fun��o attr()
                $button.attr('disabled',false);

                // Escrevo a mensagem

                $('#loadingTags').html(txt);

                // Limpo o formul�rio
                self.reset();
            },

            // Se acontecer algum erro � executada essa fun��o
            error: function(txt){
                $('#loadingTags').html("ERRO");
            }
        })
        return false;
    });
});