<?php

class Setor extends Model {

    private $chamado = array('HasMany');

    public function store() {
        try {
            unset($this->data['insert']);
            //var_dump($this->data);
            $this->descricao = $this->data['descricao'];
            $this->status = $this->data['status'];
            $this->datecreated = date("Y-m-d H:i:s");
            $this->dateupdate = date("Y-m-d H:i:s");
            if (SessionRegistry::getValue('error')) {
                return false;
            } else {
                if (!empty($this->data['id'])) {
                    parent::update();
                    return true;
                } else {

                    parent::store();
                    return true;
                }
            }
        } catch (ModelException $modelexception) {
            echo $modelexception->getMessage() . "<br>";
            Transaction::rollback();
        }
    }

    public function set_status($status) {
        if ($status == 'on') {
            $this->data['status'] = '1';
        } else {
            $this->data['status'] = '0';
        }
    }

    public function set_descricao($descricao) {
        if (strlen($descricao) < 5) {
            SessionRegistry::setValue('error', "Setor Inv�lido");
        } else {
            $this->data['descricao'] = $descricao;
        }
    }

    public function destroy() {
        try {
            $criteria = new Criteria;
            $criteria->add(new Filter('setor_id', '=', ':setor_id', $this->id));
            $repository = new Repository('chamado');
            if ($repository->destroy($criteria)) {
                parent::destroy();    
                return true;
            }
        } catch (ModelException $modelexception) {
            echo $modelexception->getMessage() . "<br>";
            Transaction::rollback();
        }
    }

}