<?php
class Usuarios extends Model
{
    public function store()
	{
	    unset($this->data['insert']);
	    unset($this->data['cadastrar']);
		
	    $this->username = $this->data['username'];
	    $this->password = crypt($this->data['password']);
	    $this->emailaddress = $this->data['emailaddress'];
	    $this->user_type = $this->data['user_type'];
	    $this->status = '1';
		$this->user_img = md5($_FILES['user_img']['name']);
		$this->user_thumb = '_thumb_' . md5($_FILES['user_img']['name']);
		$this->descricao = $this->data['descricao'];	
	    $this->datecreated = date("Y-m-d H:i:s");
	    $this->dateupdated = date("Y-m-d H:i:s");
		
		
		if($error = SessionRegistry::getValue('error'))
		{
		    unset($_SESSION['error']);
		    return false;
		}
		elseif(parent::store())
		{
            return true;		
		}    		
	}
	
	
	public function update()
	{
	}
	
	public function destroy()
	{
	}
}
?>