<?php
class Chamado extends Model
{
	public function store()
	{
	    unset($this->data['insert']);
	    unset($this->data['cadastrar']);
		
	    $this->resumo = $this->data['resumo'];
	    $this->tags = $this->data['tags'];
	    $this->descricao = $this->data['descricao'];
	    $this->comentario = $this->data['comentario'];
	    $this->requisitado_por = $this->data['requisitado_por'];
	    $this->tipo = $this->data['tipo'];
	    $this->dificuldade = $this->data['dificuldade'];
	    $this->prioridade = $this->data['prioridade'];
	    $this->setor_id = $this->data['setor_id'];
	    $this->setor_refer_id = '1';
	    $this->usuario_id = '1';
		$this->status = '1';
		$this->datecreated = date("Y-m-d H:i:s");
	    $this->dateupdated = date("Y-m-d H:i:s");
		
		if($error = SessionRegistry::getValue('error'))
		{
		    unset($_SESSION['error']);
		    return false;
		}
		elseif(parent::store())
		{
            return true;		
		}
	}
	
	public function getChamadosParaPaginaInicial($limit)
	{
		$criteria = new Criteria;
		$criteria->addJoin(array('setor AS s'=>'s.id = chamado.setor_id'),
			array('usuarios As u'=>'u.id = chamado.usuario_id'),
			array('setor_operacao As so'=>'so.id = chamado.setor_refer_id'));
		$criteria->add(new Filter('chamado.status', '=',':status',1));
		$criteria->setProperty('limit', $limit);
        $criteria->setProperty('order', 'chamado.id desc');
		
		return $this->finder()->load(null,$criteria,array(
			'u.username AS unome', 's.nome As setnome ', 'so.nome As refsetnome',
			'DATE_FORMAT(chamado.datecreated, "%d/%m/%Y/ %Hh%imin") as date',
			'chamado.resumo', 'chamado.tags', 'chamado.prioridade',
			'chamado.requisitado_por','chamado.descricao'
		));
	}
}