<?php /* Smarty version 2.6.21, created on 2013-05-12 16:35:08
         compiled from c:/wamp/www/oabpiCms/protected/views/views.index/mainAjax.tpl */ ?>
﻿<?php 
	    $user=new authUsers();
        $user->authStart();
        $user->startSessionVerify();
        $user->sessionClose();
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Dashboard - Admin Template</title>
	<script src="media/js/nicEdit.js" type="text/javascript"></script>
    <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
        <?php Partial::init()->module('ApplicationController')->message('css'); ?>
        <?php Partial::init()->module('ApplicationController')->message('styleSettings'); ?>
        <?php Partial::init()->module('ApplicationController')->message('javascripts'); ?>
        <?php Partial::init()->module('ApplicationController')->message('colorBoxSettings'); ?>
        <?php Partial::init()->module('ApplicationController')->message('datatables'); ?>

<script type="text/javascript" src="media/js/ajaxDiretorios.js"></script>
<link rel="stylesheet" type="text/css" href="http://localhost/oabpi/esapi_admin/css/theme.css" />
<link rel="stylesheet" type="text/css" href="http://localhost/oabpi/esapi_admin/css/style.css" />
<link rel="stylesheet" type="text/css" href="http://localhost/oabpi/esapi_admin/css/theme1.css" /><!--[if IE]>

		<link rel="stylesheet" type="text/css" href="/oabpi/esapi_admin/css/theme.css" />
<link rel="stylesheet" type="text/css" href="/oabpi/esapi_admin/css/style.css" />
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
<?php 
Partial::init()->module('ApplicationController')->message('globalAjaxRequest');
 ?>
<?php 
Partial::init()->module('ApplicationController')->message('jqueryUiLoad');
 ?>
 <script type="text/javascript" src="media/js/lightbox/js/jquery.lightbox-0.5.js"></script>
 <link rel="stylesheet" type="text/css" href="media/js/lightbox/css/jquery.lightbox-0.5.css" media="screen" />
 <link rel="stylesheet" type="text/css" href="media/js/chosen/chosen/chosen.css" media="screen" />

<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
   document.writeln('<link rel="stylesheet" type="text/css" href="<?php echo ConfigPath::pathRoot()  ?>concursos_new/src/ecommerce/media/admin_template/css/' + StyleFile + '">');
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
<?php echo '
<script type="text/javascript">
    $(function() {
        $(\'#gallery a\').lightBox();
		$(\'div .gallery a\').lightBox();
    });
    </script>
'; ?>


<?php echo '
<link rel="stylesheet" type="text/css" media="screen" href="media/examplefiles/css/all-examples.css">	
'; ?>

</head>

<body><!-- end div .dock #dock -->
	<!-- END DOCK 1 ============================================================ -->
	
	<!-- BEGIN DOCK 2 ============================================================ -->
	<!-- END DOCK 2 ============================================================ -->
	
	
<!-- Accordion -->
        <div id="wrapper">
            <div id="content">
              <?php 
				$frontController =_AutoLoad::getFrontController();
				$frontController->listering();
				$frontController->run();
	           ?>
            </div>
</div><?php echo '
<script src="media/js/chosen/chosen/chosen.jquery.js" type="text/javascript"></script>
  <script type="text/javascript"> $(".chzn-select").chosen(); $(".chzn-select-deselect").chosen({allow_single_deselect:true}); </script>
'; ?>

  </body>
</h
tml>