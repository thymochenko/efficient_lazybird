<?php /* Smarty version 2.6.21, created on 2012-09-14 19:35:40
         compiled from c:/wamp/www/concursos_new/src/ecommerce/protected/views/views.index/home.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 
Transitional//EN">
<html>
<head>
<title>Centrar uma  p�gina com CSS</title>
<meta http-equiv="Content-Type" content="text/html; 
charset=iso-8859-1"><?php echo '
<script>
/*
CSS Browser Selector v0.4.0 (Nov 02, 2010)
Rafael Lima (http://rafael.adm.br)
http://rafael.adm.br/css_browser_selector
License: http://creativecommons.org/licenses/by/2.5/
Contributors: http://rafael.adm.br/css_browser_selector#contributors
*/
function css_browser_selector(u){var ua=u.toLowerCase(),is=function(t){return ua.indexOf(t)>-1},g=\'gecko\',w=\'webkit\',s=\'safari\',o=\'opera\',m=\'mobile\',h=document.documentElement,b=[(!(/opera|webtv/i.test(ua))&&/msie\\s(\\d)/.test(ua))?(\'ie ie\'+RegExp.$1):is(\'firefox/2\')?g+\' ff2\':is(\'firefox/3.5\')?g+\' ff3 ff3_5\':is(\'firefox/3.6\')?g+\' ff3 ff3_6\':is(\'firefox/3\')?g+\' ff3\':is(\'gecko/\')?g:is(\'opera\')?o+(/version\\/(\\d+)/.test(ua)?\' \'+o+RegExp.$1:(/opera(\\s|\\/)(\\d+)/.test(ua)?\' \'+o+RegExp.$2:\'\')):is(\'konqueror\')?\'konqueror\':is(\'blackberry\')?m+\' blackberry\':is(\'android\')?m+\' android\':is(\'chrome\')?w+\' chrome\':is(\'iron\')?w+\' iron\':is(\'applewebkit/\')?w+\' \'+s+(/version\\/(\\d+)/.test(ua)?\' \'+s+RegExp.$1:\'\'):is(\'mozilla/\')?g:\'\',is(\'j2me\')?m+\' j2me\':is(\'iphone\')?m+\' iphone\':is(\'ipod\')?m+\' ipod\':is(\'ipad\')?m+\' ipad\':is(\'mac\')?\'mac\':is(\'darwin\')?\'mac\':is(\'webtv\')?\'webtv\':is(\'win\')?\'win\'+(is(\'windows nt 6.0\')?\' vista\':\'\'):is(\'freebsd\')?\'freebsd\':(is(\'x11\')||is(\'linux\'))?\'linux\':\'\',\'js\']; c = b.join(\' \'); h.className += \' \'+c; return c;}; css_browser_selector(navigator.userAgent);
</script>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.5.3/jquery-ui.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
	    $("#featured > ul").tabs({fx:{opacity: "toggle"}}).tabs("rotate",5000,true);
	});
</script>
<!--
<script>
$(document).ready(function(){
    //esconde a div contendo o submenu 
	$("#submenu").hide();
	//ao passar o mouse sobre determinado campo, exibe a div
	$(".esapi_link").mouseover(function () {
        $("#submenu").show("slow");
        });
	});
</script>
-->
<style type="text/css">
body {
	margin:0;
	padding:0;
	background:url(http://localhost/concursos_new/src/ecommerce/media/images/bg.jpg) top center repeat-x;
	text-align:center; /* hack para o IE */
    font-family:Arial, Helvetica, sans-serif;text-decoration:none;color:#888;	
	}
	
#tudo {
	width: 990px;
	margin:0 auto;			
	text-align:left; /* "rem�dio" para o hack do IE */	
	}
	
#conteudo
    {
	padding: 5px;
	background-color: #fff;
	border-style:solid;
	border-bottom-width:1px;
    border-color:#eee;
	}
	
	#botaoindex
	{
	    position:relative;
		left:430px;
		top:-77px;
	}
	
	#busca
	{
	    position:relative;
		left:612px;
		top:-90px;
	}
	
	input
	{	
        background:#f4f4f4;	
        border:1px solid #eee;
    }
	
	.input_stl
	{
	    line-height:28px;
		width:280px;
	}
	
	.artigo_box_img
	{
	    position:relative;
		
	}
	
	#menu ul li
	{
	    display: inline; margin: 0;
	    padding: 0 10px;
	    height: 36px;
	    line-height: 35px;
	    text-decoration: none;
	    font-weight: bold;
	    font-size: 17px;
	    position:relative;
	    top:-79px;
	    left:210px;
	    background: #f4f4f4 url(../img/bg_menu_blue.jpg) repeat-x top;
	    border-left: #ccc 6px solid;
	    border-right: #ccc 1px solid;
	    border-top: #ccc 1px solid;
	    border-bottom: #ccc 1px solid;
	}

	#menu
	{
	    background-color:#FFF;color:#CCC;
	}
    
	.title_post_link a:link  {color:#eee;text-decoration:none;}
    .title_post_link a:hover {color:#0066CC;background-color:#eee; text-decoration:underline;}
    .title_post_link a:active{color:#eee;text-decoration:none;}
    .title_post_link a:visited{color:#eee;text-decoration:none;}
    
	
    .menu_link a:link  {color:#666;text-decoration:none;}
    .menu_link a:hover {color:#fff;background-color:#0099CC; text-decoration:underline;}
    .menu_link a:active{color:#666;text-decoration:none;}
    .menu_link a:visited{color:#666;text-decoration:none;}
	
    a:link  {color:#888;text-decoration:none;}
    a:hover {color:#0066CC;background-color:#fff; text-decoration:underline;}
    a:active{color:#666;text-decoration:none;}
    a:visited{color:#666;text-decoration:none;}
	
	#slideshow
	{
	    position:relative;
	    top:-79px;  
        left:16px;	
	}
	
	.artigos
	{
	width:500px;
	top:-79px;  
    left:1px;
	word-spacing:2px;
	}
	
	hr{
	  position:relative;
	  top:-20px;
	  border-top: 1px solid #fff;
      border-bottom: 1px solid #eee;
      color: #fff;
      background-color: #f4f4f4;
      height: 4px;
	  width:420px;
	  left:-20px;
	}
	
    .datepost
	{
	    position:relative;
		bottom:50px;
		left:425px;
	}
	
	.title_artigo
	{
	    position:relative;
	    top:-60px;
	    padding-left:20px;
	    color:#888;
	}
	
	.post_artigo
	{
	    position:relative;
	    top:-72px;
	    padding-left:25px;
	    background:url(http://localhost/concursos_new/src/ecommerce/media/images/bg_post.jpg) top center repeat-x;
		padding-rigth:20px;
	}
	
	.noticias
	{
	    float:left;
	}
	
	#container
	{
	    float:left;
		position:relative;
		top:-80px;
	}
	
	#boxDireito
	{
	    display:inline;
		position:relative;
		background-color:#ccc;
	}
	
	#curso_m
	{
		position:relative;
	    left:30px;
		top:-99px;
		width:430px;
		float:left;
	}
	
	.artigo_box_img
	{
		position:relative;
		left:15px;
		top:4px;
        z-index:1;
	}
	
	#featured
	{ 
	width:690px; 
	padding-right:250px; 
	position:relative; 
	border:5px solid #ccc; 
	height:250px; overflow:hidden;
	background:#fff;
    }
	
#featured ul.ui-tabs-nav{ 
	position:absolute; 
	top:0; left:700px; 
	list-style:none; 
	padding:0; margin:0; 
	width:250px; height:250px;
	overflow:auto;
	overflow-x:hidden;
}

#featured ul.ui-tabs-nav li{ 
	padding:1px 0; padding-left:13px;  
	font-size:12px; 
	color:#666; 
}

#featured ul.ui-tabs-nav li img{ 
	float:left; margin:2px 5px; 
	background:#fff; 
	padding:2px; 
	border:1px solid #eee;
}

#featured ul.ui-tabs-nav li span{ 
	font-size:11px; font-family:Verdana; 
	line-height:18px; 
}

#featured li.ui-tabs-nav-item a{ 
	display:block; 
	height:60px; text-decoration:none;
	color:#333;  background:#fff; 
	line-height:20px; outline:none;
}

#featured li.ui-tabs-nav-item a:hover{ 
	background:#f2f2f2; 
}

#featured li.ui-tabs-selected{ 
	background:url(\'http://localhost/concursos_new/src/ecommerce/media/images/images/selected-item.gif\') top left no-repeat;  
}

#featured ul.ui-tabs-nav li.ui-tabs-selected a{ 
	background:#ccc; 
}

#featured .ui-tabs-panel{ 
	width:710px; height:250px; 
	background:#999; position:relative;
}

#featured .ui-tabs-panel .info{ 
	position:absolute; 
	bottom:0; left:0; 
	height:70px; 
	background: url(\'http://localhost/concursos_new/src/ecommerce/media/images/transparent-bg.png\'); 
}

#featured .ui-tabs-panel .info a.hideshow{
	position:absolute; font-size:11px; font-family:Verdana; color:#f0f0f0; right:10px; top:-20px; line-height:20px; margin:0; outline:none; background:#333;
}

#featured .info h2{ 
	font-size:1.2em; font-family:Georgia, serif; 
	color:#fff; padding:5px; margin:0; font-weight:normal;
	overflow:hidden; 
}

#featured .info p{ 
	margin:0 5px; 
	font-family:Verdana; font-size:11px; 
	line-height:15px; color:#f0f0f0;
}

#featured .info a{ 
	text-decoration:none; 
	color:#fff; 
}

#featured .info a:hover{ 
	text-decoration:underline; 
}

#featured .ui-tabs-hide{ 
	display:none; 
}

.boxface
{
    position:relative;
	top:-60px;
}

</style>
'; ?>

</head>
<body>
<div id="tudo">
	<div id="conteudo">
	<!-- box que contem o primeiro nivel de divs contendo a caixa de busca os cursos solicitados(Session) e um botao-->
		<div id="boxEsquerdo">
		    <div id="logo"><img src="http://localhost/concursos_new/src/ecommerce/media/images/esapilogo.jpg"/></div>
			<div id="botaoindex">
			    <a href="/index"><br></a>
			</div>
		    <div id="busca">
			    <form name="busca" action="/seach_index">
				<input type="text" name="seach_index" id="seach_index" class="input_stl"/>
				<input type="submit" name="busca" value="busca">
				</form>
			</div>
			
		    <div id="menu">
			    <ul>
				    <li><a class="esapi_link" href="#">ESAPI</a></li>
				    <li><a class="menu_link" href="#">CURSOS</a></li>
				    <li><a class="menu_link" href="#">NOTICIAS</a></li>
				    <li><a class="menu_link" href="#">ARTIGOS</a></li>
				    <li><a class="menu_link" href="#">CADASTRO</a></li>
				    <li><a class="menu_link" href="#">CONTATO</a></li>
				    <li><a class="menu_link" href="#">ALUNO</a></li>
			    </ul>
			</div>
		<div id="slideshow">
		    <div id="featured" >
		  <ul class="ui-tabs-nav">
	        <li class="ui-tabs-nav-item ui-tabs-selected" id="nav-fragment-1">
			<a href="#fragment-1">
			<img src="http://esaoabsp.edu.br/Imagem/15_5_2012__3_00_00_0__W08.jpg" width="50" height="50" alt="" />
			<span>15+ Excellent High Speed Photographs</span></a></li>
	        <li class="ui-tabs-nav-item" id="nav-fragment-2"><a href="#fragment-2"><img src="http://esaoabsp.edu.br/Imagem/23_4_2012__3_00_00_0__w07.jpg" alt="" width="50" height="50" alt="" /><span>20 Beautiful Long Exposure Photographs</span></a></li>
	        <li class="ui-tabs-nav-item" id="nav-fragment-3"><a href="#fragment-3"><img src="http://esaoabsp.edu.br/Imagem/06_07_2012__03_00_00_0__SORTEIOS_II.jpg" width="50" height="50" alt="" /><span>35 Amazing Logo Designs</span></a></li>
	        <li class="ui-tabs-nav-item" id="nav-fragment-3"><a href="#fragment-3"><img src="http://esaoabsp.edu.br/Imagem/06_07_2012__03_00_00_0__SORTEIOS_II.jpg" width="50" height="50" alt="" /><span>35 Amazing Logo Designs</span></a></li>
	      </ul>
	    <!-- First Content -->
	    <div id="fragment-1" class="ui-tabs-panel" style="">
			<img src="http://esaoabsp.edu.br/Imagem/15_5_2012__3_00_00_0__W08.jpg" alt="" width="710"/>
			 <div class="info">
				<h2><a href="#">15+ Excellent High Speed Photographs</a></h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tincidunt condimentum lacus. Pellentesque ut diam....<a href="#" >read more</a></p>
			 </div>
	    </div>

	    <!-- Second Content -->
	    <div id="fragment-2" class="ui-tabs-panel ui-tabs-hide" style="">
			<img src="http://esaoabsp.edu.br/Imagem/23_4_2012__3_00_00_0__w07.jpg" alt="" width="710"/>
			 <div class="info" >
				<h2><a href="#" >20 Beautiful Long Exposure Photographs</a></h2>
				<p>Vestibulum leo quam, accumsan nec porttitor a, euismod ac tortor. Sed ipsum lorem, sagittis non egestas id, suscipit....<a href="#" >read more</a></p>
			 </div>
	    </div>

	    <!-- Third Content -->
	    <div id="fragment-3" class="ui-tabs-panel ui-tabs-hide" style="">
			<img src="http://esaoabsp.edu.br/Imagem/06_07_2012__03_00_00_0__SORTEIOS_II.jpg" alt="" width="710" />
			 <div class="info" >
				<h2><a href="#" >35 Amazing Logo Designs</a></h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tincidunt condimentum lacus. Pellentesque ut diam....<a href="#" >read more</a></p>
			 </div>
	    </div>

	    <!-- Fourth Content -->
	    <div id="fragment-4" class="ui-tabs-panel ui-tabs-hide" style="">
			<img src="http://esaoabsp.edu.br/Imagem/06_07_2012__03_00_00_0__SORTEIOS_II.jpg" alt="" width="710" />
			 <div class="info" >
				<h2><a href="#" >35 Amazing Logo Designs</a></h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tincidunt condimentum lacus. Pellentesque ut diam....<a href="#" >read more</a></p>
			 </div>
	    </div>

		</div>
	</div>

		</div>
		
		<br>
		
		<div id="container">
		     <div class="artigos">
			 <img class="artigo_box_img" src="http://localhost/concursos_new/src/ecommerce/media/images/box.jpg" id="ContentPlaceHolder1_rpNoticias_imgImagem_0"  />
			 <hr>
			 <span class="datepost"><br></span>
			 <div class="title_artigo">
			     <h2><a href="#" class="title_post_link">Crnica de uma vida anunciada, quero dizer, de vrias vidas anunciadas</a></h2>
			 </div>
<div class="post_artigo">
				 <img style="float:left; position:relative;left:-5px;" src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />O hergrego  trgico porque pretende lutar contra as foas do destino e como,
 por mais que faa, no consegue venc-lo, ao final d-se a tragdia. 
 Mas, se posvel vencer o destino? N costumamos descrever certos acontecimentos 
 como uma fatalidade, como algo inevvel, que havia mesmo de ocorrer, fizesse o que se 
			 </div>
			 <span class="boxface">COMPARTILHAR  <img src="http://localhost/concursos_new/src/ecommerce/media/images/images.png" width="20" heigth="20"/> - 21/02/2012 </span>
			 
			 <hr>
			 
			</div>
			
			<div class="artigos">
			<div class="title_artigo"><h2><a href="#" class="title_post_link">Crnica de uma vida anunciada, quero dizer, de vrias vidas anunciadas</a></h2></div>
            <div class="post_artigo">
			<img style="float:left; position:relative;left:-5px;" src="http://esaoabsp.edu.br/Imagem/Noticia/28_6_2012__3_00_00_0__Elisabeth%20e%20Camila.jpg" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />O hergrego  trgico porque pretende lutar contra as foas do destino e como,
 por mais que faa, no consegue venc-lo, ao final d-se a tragdia. 
 Mas, se posvel vencer o destino? N costumamos descrever certos acontecimentos 
 como uma fatalidade, como algo inevvel, que havia mesmo de ocorrer, fizesse o que se 
			 </div>			 <hr>
			 <span class="datepost">21/02/2012</span>
			 <div class="title_artigo"><h2><a href="#" class="title_post_link">Crnica de uma vida anunciada, quero dizer, de vrias vidas anunciadas</a></h2></div>
<div class="post_artigo">
				 <img style="float:left; position:relative;left:-5px;" src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />O hergrego  trgico porque pretende lutar contra as foas do destino e como,
 por mais que faa, no consegue venc-lo, ao final d-se a tragdia. 
 Mas, se posvel vencer o destino? N costumamos descrever certos acontecimentos 
 como uma fatalidade, como algo inevvel, que havia mesmo de ocorrer, fizesse o que se 
			<h3>Ler todas as not�cias </h3>
			</div>
			<span class="datepost">21/02/2012</span>
	</div>
	
	<div id="noticia">
<img class="artigo_box_img" src="http://localhost/concursos_new/src/ecommerce/media/images/box_not.jpg" id="ContentPlaceHolder1_rpNoticias_imgImagem_0"  /> 
<hr>					
		     <div class="noticias">
			     <img src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />
			     <div id="title_post">Novos Advogados entrando na Ordem</div>
			 </div> 
			 	 <div class="noticias">
			     <img src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />
			     <div id="title_post">New Advogados entrando na Ordem</div>
			 </div>
	</div>
	
	</div></div><!-- endboxEsquerdo -->
    <br>	
	<div id="curso_m">
		     <div class="cursos_m">
				 <img class="artigo_box_img" src="http://localhost/concursos_new/src/ecommerce/media/images/box_t.jpg" id="ContentPlaceHolder1_rpNoticias_imgImagem_0"  />
				 <hr>
				  
				 <div id="title_post_m"><b>21/02/2012</b><a href="#" class="title_post_link"> - Introdu��o ao direito Imobili�rio - 1 - Conceitos</a></div>
			 </div>
			 <br>
            <div class="cursos_m">
			
			<br>
			
				 <hr>
				  
				 <div id="title_post_m"><b>21/02/2012</b><a href="#" class="title_post_link"> - Contabilidade para Advogados - Retorno  </a></div>
			 </div>
			
			<div class="cursos_m">
			<br>
				 <hr>  
				 <div id="title_post_m"><b>21/02/2012</b><a href="#" class="title_post_link"> - Direito e inform�tica - As amea�as da internet </a></div>
			 </div>
			
			<div>
			<br>
				 <hr>
				 <div id="title_post_m"><b>21/02/2012</b><a href="#" class="title_post_link"> - Gest�o processual com PJE como ferramenta</a></div>
			 </div>
	    </div>
		<br><br>
		
	<div id="boxDireito">
	<div id="curso_m">
		     <div class="cursos_m">
			     <img class="artigo_box_img" src="http://localhost/concursos_new/src/ecommerce/media/images/box_C.jpg" id="ContentPlaceHolder1_rpNoticias_imgImagem_0"  />
			 
				 <hr>
				 <div id="title_post_m" style="float:left"><b>21/02/2012</b> -<h3>Curso de Direito <br>
				  Administrativo</h3></div>
				 <img src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />
				 
			 </div>
			 <br>
			 
 <div class="cursos_m">
			     
				 <hr>
				 
				 <div id="title_post_m" style="float:left"><b>21/02/2012</b> -<h3>Curso de Direito <br>
				 e Conta</h3>
				 </div>
				 
				 <img src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107" />
				 
			 </div>
			 <br>
			 
 <div class="cursos_m">
			     
				<hr>
				 
				 <div id="title_post_m" style="float:left"><b>21/02/2012</b> -<h3>Curso de Direito <br>
				 e Conta</h3></div>
				 <img src="http://www.esaoabsp.edu.br/Imagem/Noticia/04_07_2012__03_00_00_0__Foto%20da%20classe%20-%20com%20Joao%20Candido%20e%20Maria%20Edina.JPG" id="ContentPlaceHolder1_rpNoticias_imgImagem_1" width="147" height="107"/>	 
			</div>
	    </div>
		<br>
	    </div>
		<br>
		<br>
	</div><!-- boxDireito -->
<div id="blocknavrapida">
<div id="redes"></div>
</div>
<div id="menuhelpbox">
</div>
<div id="menuhelpbox2"></div>
<div id="parceiros"></div>
<div id="rodape"></div>
</div>
</div>
</body>
</html>