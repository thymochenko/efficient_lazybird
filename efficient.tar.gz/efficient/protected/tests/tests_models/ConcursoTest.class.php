<?php
include_once('../../config/bootstrap.php');

$frontController=_AutoLoad::getFrontController();
$frontController->run();
		
class ConcursoTest extends UnitTestCase
{
    public function testOfGetAll()
	{
	    Transaction::open();
	    $concurso = new Concurso;	
		$this->assertNotNull($concurso->finder()->findAll());
	}
}
?>