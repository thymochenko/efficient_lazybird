<?php
class UsuariosAction extends ApplicationController
{
    public function add()
	{
	    $this->render(array(
		    'collection'=>array(null), 'template'=>'add')
	    );
	}
	
	public function store()
	{
	    if($_POST['insert'])
		{
		    $usuario = new Usuarios;
		    $usuario->fromArray($this->request()->post());
		    if($usuario->store())
			{
                Message::_get('Info', "<h2> Cadastro realizada com sucesso</h2>");
				$this->redirect(array(
				    'class'=>'usuarios',
				    'method'=>'listar',
					'type'=>array('timeRedirect'=>1000))
				); 
			}
			else
			{
			    $errorMessage = utf8_encode('<h2>' . SessionRegistry::getValue('error') . '</h2>');
			    Message::_get('Error',$errorMessage);
			}
		}
	}
}
?>