<?php
class ArquivosAction extends ApplicationController
{
    public function adicionar()
	{
	    $this->render(array(
		    'collection'=>array(null))
	    );
	}
	
	public function add()
	{
	    $this->render(array(
		    'collection'=>array(null))
	    );
	}
	
    public function listar()
	{
	    $expr = array('entity'
			=> array('Arquivos'),
			'attributes' => array(null),
			'where'=>array('status','=',':status',1),
			'order' => array('id' => 'desc'),
			'limit' => array(500)
		);
		
	    $this->render(array(
		    'collection'=>Model::object($this)->finder()->find($expr))
	    );
	}
	
    public function store()
	{
	    if($_FILES)
		{
		    $arquivo = new Arquivos;
		    $arquivo->fromArray(array('file'=>$_FILES,'post'=>$this->request()->post()));
			
		    if($arquivo->store())
			{
				echo json_encode(array('status'=>"Imagem Enviada com sucesso"));
			}
			else
			{
			    $errorMessage = '<h2>' . SessionRegistry::getValue('error') . '</h2>';
			    Message::_get('Error',$errorMessage);
			}
		}
	}
	
	public function storeFilesOnlyAction()
	{
	    if($_FILES)
		{
		    $arquivo = new Arquivos;
		    $arquivo->fromArray(array('file'=>$_FILES,'post'=>$this->request()->post()));
			
		    if($arquivo->storeFilesOnly())
			{
				Message::_get('Info', "<h2> Arquivos inseridos com sucesso</h2>");
			}
			else
			{
			    $errorMessage = '<h2>' . SessionRegistry::getValue('error') . '</h2>';
			    Message::_get('Error',$errorMessage);
			}
		}
	}
	
	public function storeTextAreaImage()
	{
		if($_FILES)
		{
		    $arquivo = new Arquivos;
		    $arquivo->fromArray(array('file'=>$_FILES,'post'=>$this->request()->post()));
			
		    if($arquivo->storeTextAreaFile())
			{
			    $status['done'] = 1;
				$status['width'] = 'null';
				$status['url'] = 'http://localhost/oabpiCms/media/files/' . $_FILES['nicImage']['name'];
	
				 $script = '
				try {
				'.(($_SERVER['REQUEST_METHOD']=='POST') ? 'top.' : '')
				.'nicUploadButton.statusCb('.json_encode($status).');
				} catch(e) { alert(e.message); }
				';
    
				if($_SERVER['REQUEST_METHOD']=='POST') {
					echo '<script>'.$script.'</script>';
			    } else {
					echo $script;
				}
			}
			else
			{
			    $errorMessage = '<h2>' . SessionRegistry::getValue('error') . '</h2>';
			    Message::_get('Error',$errorMessage);
			}
		}
	}
	
	public function update()
	{
	    if($_POST['update'])
		{
		    $arquivo = new Arquivos;
		    $arquivo->fromArray(array('file'=>$_FILES,'post'=>$this->request()->post()));
		    if($arquivo->update())
			{
			    Message::_get('Info', "<h2> Atualiza��o realizada com sucesso</h2>");
				
				$this->redirect(array(
				    'class'=>'arquivos',
				    'method'=>'listar',
					'type'=>array('timeRedirect'=>1000))
				); 
			}
			else
			{
			    $errorMessage = '<h2>' . SessionRegistry::getValue('error') . '</h2>';
			    Message::_get('Error',$errorMessage);
			}
		}
	}
	
	public function destroy()
	{   
	    if($_GET['id'])
		{    
		    if(Model::object($this)
			->destroy($this->request()->get('stdClass')->id))
			{
			    Message::_get('Info', "<h2> Objeto excluido com sucesso</h2>");
				$this->redirect(array(
				    'class'=>'Arquivos',
				    'method'=>'listar',
					'type'=>array('timeRedirect'=>1000))
				);   
			}
			else
			{
				$errorMessage = '<h2>' . SessionRegistry::getValue('error') . '</h2>';
			    Message::_get('Error',$errorMessage);
			}
		}
	}
	
	public function modalExcluir()
	{
	    $arq = Model::object($this)
		->finder()->findById((int)$this->request()->get('stdClass')->id);	
		
		if($arq)
		{
			$this->render(array('collection' => $arq));
		}
		
	}
	
	public function atualizar()
	{
	    if(isset($_GET['id']))
		{
	        $collection = Model::object($this)->finder()
			->findById((int)$this->request()->get('stdClass')->id);
			
			$this->render(array('collection'=>$collection));
		}
	}
}
?>