<?php include('protected/config/bootstrap.php');

$view = new ApplicationController();
$view->_staticRender('index','index');
?>